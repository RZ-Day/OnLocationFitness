package com.olfit.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnLocationFitnessApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnLocationFitnessApplication.class, args);
	}

}
