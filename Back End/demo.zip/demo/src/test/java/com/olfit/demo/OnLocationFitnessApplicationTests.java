package com.olfit.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnLocationFitnessApplicationTests {

	@Test
	void contextLoads() {
	}

}
